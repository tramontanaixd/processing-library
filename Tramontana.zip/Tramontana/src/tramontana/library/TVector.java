package tramontana.library;

public class TVector{
	public int x;
	public int y;
	public TVector(int x, int y)
	{
		this.x=x;
		this.y=y;
	}
	
}
